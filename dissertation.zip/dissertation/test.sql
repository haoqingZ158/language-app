-- Create user list
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL
);

-- Insert a test data
INSERT INTO users (id, username, password) 
VALUES (1, '23029461', '123456');
