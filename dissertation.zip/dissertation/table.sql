-- 创建用户表 (Users)
CREATE TABLE Users (
    UserID INT PRIMARY KEY AUTO_INCREMENT,
    Username VARCHAR(50) UNIQUE NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    NativeLanguage VARCHAR(50) NOT NULL,
    LearningLanguages TEXT NOT NULL,
    ProfileBio TEXT,
    ProfilePicture VARCHAR(255),
    RegistrationDate DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 创建对话表 (Conversations)
CREATE TABLE Conversations (
    ConversationID INT PRIMARY KEY AUTO_INCREMENT,
    InitiatorUserID INT NOT NULL,
    ParticipantUserID INT NOT NULL,
    StartTime DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (InitiatorUserID) REFERENCES Users(UserID),
    FOREIGN KEY (ParticipantUserID) REFERENCES Users(UserID)
);

-- 创建消息表 (Messages)
CREATE TABLE Messages (
    MessageID INT PRIMARY KEY AUTO_INCREMENT,
    ConversationID INT NOT NULL,
    SenderUserID INT NOT NULL,
    Content TEXT NOT NULL,
    SentTime DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ConversationID) REFERENCES Conversations(ConversationID),
    FOREIGN KEY (SenderUserID) REFERENCES Users(UserID)
);

-- 创建预约表 (Appointments)
CREATE TABLE Appointments (
    AppointmentID INT PRIMARY KEY AUTO_INCREMENT,
    InitiatorUserID INT NOT NULL,
    ParticipantUserID INT NOT NULL,
    AppointmentTime DATETIME NOT NULL,
    Status ENUM('Pending', 'Confirmed', 'Cancelled') DEFAULT 'Pending',
    FOREIGN KEY (InitiatorUserID) REFERENCES Users(UserID),
    FOREIGN KEY (ParticipantUserID) REFERENCES Users(UserID)
);

-- 创建反馈表 (Feedbacks)
CREATE TABLE Feedbacks (
    FeedbackID INT PRIMARY KEY AUTO_INCREMENT,
    ConversationID INT NOT NULL,
    ReviewerUserID INT NOT NULL,
    Rating INT CHECK (Rating >= 1 AND Rating <= 5),
    Comment TEXT,
    FOREIGN KEY (ConversationID) REFERENCES Conversations(ConversationID),
    FOREIGN KEY (ReviewerUserID) REFERENCES Users(UserID)
);
