package com.example.languageapp.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MatchActivity : AppCompatActivity() {

    private lateinit var matchListView: ListView
    private val matches = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_match)

        matchListView = findViewById(R.id.matchListView)

        // Simulate loading matches (in a real app, you would load this from a database or server)
        loadMatches()

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, matches)
        matchListView.adapter = adapter
    }

    private fun loadMatches() {
        // Simulate fetching matches
        // For simplicity, using static data here
        matches.add("Alice")
        matches.add("Charlie")
    }
}
