package com.example.languageapp.ui

object NetworkUtils {

    fun sendLike(username: String?) {
        // Simulate network request
        println("Like sent for user: $username")
    }
}
