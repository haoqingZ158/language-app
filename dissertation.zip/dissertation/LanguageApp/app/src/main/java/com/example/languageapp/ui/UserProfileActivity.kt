package com.example.languageapp.ui


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class UserProfileActivity : AppCompatActivity() {

    private lateinit var userName: TextView
    private lateinit var userProfileImage: ImageView
    private lateinit var likeButton: Button
    private lateinit var dislikeButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile)

        userName = findViewById(R.id.userName)
        userProfileImage = findViewById(R.id.userProfileImage)
        likeButton = findViewById(R.id.likeButton)
        dislikeButton = findViewById(R.id.dislikeButton)

        val username = intent.getStringExtra("username")
        userName.text = username

        likeButton.setOnClickListener {
            // Handle like action
            // Save like in database or perform network request
            saveLike(username)
            val intent = Intent(this, MatchActivity::class.java)
            startActivity(intent)
        }

        dislikeButton.setOnClickListener {
            finish() // Close the activity
        }
    }

    private fun saveLike(username: String?) {
        // Simulate saving like (you should save it to the database or server here)
        NetworkUtils.sendLike(username)
    }
}
